const SUBJECT_GROUPS = [
  {
    label: "Core and Mainstream",
    options: [
      "Accounting",
      "Agricultural Management Practices",
      "Agricultural Sciences",
      "Agricultural Technology",
      "Business Studies",
      "Civil Technology",
      "Computer Applications Technology",
      "Consumer Studies",
      "Dance Studies",
      "Design",
      "Dramatic Arts",
      "Economics",
      "Electrical Technology",
      "Engineering Graphics and Design",
      "Geography",
      "History",
      "Hospitality Studies",
      "Information Technology",
      "Life Orientation",
      "Life Sciences",
      "Marine Sciences",
      "Mathematical Literacy",
      "Mathematics",
      "Mathematics (Paper 3)",
      "Mechanical Technology",
      "Music",
      "Physical Sciences",
      "Religion Studies",
      "Technical Mathematics",
      "Technical Sciences",
      "Tourism",
      "Visual Arts",
    ],
  },
  {
    label: "Technical Specialisations",
    options: [
      "Civil Technology (Civil Services)",
      "Civil Technology (Construction)",
      "Civil Technology (Woodworking)",
      "Electrical Technology (Digital Systems)",
      "Electrical Technology (Electronics)",
      "Electrical Technology (Power Systems)",
      "Mechanical Technology (Automotive)",
      "Mechanical Technology (Fitting and Machining)",
      "Mechanical Technology (Welding and Metalwork)",
    ],
  },
  {
    label: "Official SA Languages",
    options: [
      "Afrikaans Home Language",
      "Afrikaans First Additional Language",
      "Afrikaans Second Additional Language",
      "English Home Language",
      "English First Additional Language",
      "English Second Additional Language",
      "isiNdebele Home Language",
      "isiNdebele First Additional Language",
      "isiNdebele Second Additional Language",
      "isiXhosa Home Language",
      "isiXhosa First Additional Language",
      "isiXhosa Second Additional Language",
      "isiZulu Home Language",
      "isiZulu First Additional Language",
      "isiZulu Second Additional Language",
      "Sepedi Home Language",
      "Sepedi First Additional Language",
      "Sepedi Second Additional Language",
      "Sesotho Home Language",
      "Sesotho First Additional Language",
      "Sesotho Second Additional Language",
      "Setswana Home Language",
      "Setswana First Additional Language",
      "Setswana Second Additional Language",
      "SiSwati Home Language",
      "SiSwati First Additional Language",
      "SiSwati Second Additional Language",
      "South African Sign Language Home Language",
      "Tshivenda Home Language",
      "Tshivenda First Additional Language",
      "Tshivenda Second Additional Language",
      "Xitsonga Home Language",
      "Xitsonga First Additional Language",
      "Xitsonga Second Additional Language",
    ],
  },
  {
    label: "Other Approved Languages",
    options: [
      "Arabic Second Additional Language",
      "French Second Additional Language",
      "German Home Language",
      "German Second Additional Language",
      "Gujarati Home Language",
      "Gujarati First Additional Language",
      "Gujarati Second Additional Language",
      "Hebrew Second Additional Language",
      "Hindi Home Language",
      "Hindi First Additional Language",
      "Hindi Second Additional Language",
      "Italian Second Additional Language",
      "Latin Second Additional Language",
      "Portuguese Home Language",
      "Portuguese First Additional Language",
      "Portuguese Second Additional Language",
      "Spanish Second Additional Language",
      "Tamil Home Language",
      "Tamil First Additional Language",
      "Tamil Second Additional Language",
      "Telugu Home Language",
      "Telugu First Additional Language",
      "Telugu Second Additional Language",
      "Urdu Home Language",
      "Urdu First Additional Language",
      "Urdu Second Additional Language",
    ],
  },
  {
    label: "Legacy / Track-Specific",
    options: [
      "French First Additional Language (Abitur)",
      "German Mother Tongue (Abitur)",
      "History (Abitur)",
      "Biology (Abitur)",
      "Chemistry (Abitur)",
      "Physics (Abitur)",
    ],
  },
  {
    label: "IEB / Advanced Programme",
    options: [
      "Advanced Programme English",
      "Advanced Programme Afrikaans",
      "Advanced Programme Mathematics",
      "Advanced Programme Physics",
      "Advanced Programme French",
    ],
  },
];

const STORAGE_KEYS = {
  lastResult: "unipath_last_result_v3",
  rulesCache: "unipath_rules_cache_v2",
};

let universityRules = [];
const ENFORCE_SUBJECT_MINIMUMS = true;

const dom = {
  form: document.getElementById("aps-form"),
  gradeSource: document.getElementById("grade-source"),
  gradeSourceNotice: document.getElementById("grade-source-notice"),
  subjects: document.getElementById("subjects"),
  addSubjectBtn: document.getElementById("add-subject-btn"),
  resetAllBtn: document.getElementById("reset-all-btn"),
  subjectRowTemplate: document.getElementById("subject-row-template"),
  errors: document.getElementById("errors"),
  confidenceNotice: document.getElementById("confidence-notice"),
  improvementModel: document.getElementById("improvement-model"),
  results: document.getElementById("results"),
};

function isEnglishSubject(subject) {
  return subject.startsWith("English ");
}

function isMathChoice(subject) {
  return subject === "Mathematics" || subject === "Mathematical Literacy";
}

function isPredictiveGradeSource(gradeSource) {
  return gradeSource === "grade11_final" || gradeSource === "grade12_midyear";
}

function getConfidenceLabel(gradeSource) {
  if (gradeSource === "grade11_final") return "Moderate";
  if (gradeSource === "grade12_midyear") return "High";
  return "Confirmed";
}

function updateGradeSourceNotice() {
  if (dom.gradeSource.value === "grade11_final") {
    dom.gradeSourceNotice.textContent = "Please enter your final Grade 11 year-end marks only.";
    return;
  }
  dom.gradeSourceNotice.textContent = "";
}

function populateSubjectSelect(select, query = "", selectedSubject = "") {
  const normalizedQuery = query.trim().toLowerCase();
  select.innerHTML = "";

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = normalizedQuery ? "Select subject (filtered)" : "Select subject";
  select.appendChild(placeholder);

  let totalMatches = 0;
  SUBJECT_GROUPS.forEach((group) => {
    const matches = group.options.filter((subject) => subject.toLowerCase().includes(normalizedQuery));
    if (!matches.length) return;

    const optGroup = document.createElement("optgroup");
    optGroup.label = group.label;
    matches.forEach((subject) => {
      const opt = document.createElement("option");
      opt.value = subject;
      opt.textContent = subject;
      optGroup.appendChild(opt);
      totalMatches += 1;
    });
    select.appendChild(optGroup);
  });

  if (!totalMatches) {
    const none = document.createElement("option");
    none.value = "";
    none.disabled = true;
    none.textContent = "No matching subjects";
    select.appendChild(none);
  }

  select.value = selectedSubject;
}

function percentageToNSCLevel(mark) {
  if (mark >= 80) return 7;
  if (mark >= 70) return 6;
  if (mark >= 60) return 5;
  if (mark >= 50) return 4;
  if (mark >= 40) return 3;
  if (mark >= 30) return 2;
  return 1;
}

function pointsOtherFromMark(mark) {
  if (mark >= 90) return 8;
  if (mark >= 80) return 7;
  if (mark >= 70) return 6;
  if (mark >= 60) return 5;
  if (mark >= 50) return 4;
  if (mark >= 40) return 3;
  if (mark >= 30) return 2;
  return 0;
}

function pointsEnglishMathWits(mark) {
  if (mark >= 90) return 10;
  if (mark >= 80) return 9;
  if (mark >= 70) return 8;
  if (mark >= 60) return 7;
  if (mark >= 50) return 4;
  if (mark >= 40) return 3;
  return 0;
}

function pointsLifeOrientationWits(mark) {
  if (mark >= 90) return 4;
  if (mark >= 80) return 3;
  if (mark >= 70) return 2;
  if (mark >= 60) return 1;
  return 0;
}

function pointsUwcEnglishMath(mark) {
  if (mark >= 90) return 15;
  if (mark >= 80) return 13;
  if (mark >= 70) return 11;
  if (mark >= 60) return 9;
  if (mark >= 50) return 7;
  if (mark >= 40) return 5;
  if (mark >= 30) return 3;
  if (mark >= 20) return 1;
  return 0;
}

function pointsUwcOther(mark) {
  if (mark >= 90) return 8;
  if (mark >= 80) return 7;
  if (mark >= 70) return 6;
  if (mark >= 60) return 5;
  if (mark >= 50) return 4;
  if (mark >= 40) return 3;
  if (mark >= 30) return 2;
  if (mark >= 20) return 1;
  return 0;
}

function pointsUwcLO(mark) {
  if (mark >= 80) return 3;
  if (mark >= 50) return 2;
  if (mark >= 20) return 1;
  return 0;
}

function addSubjectRow(selectedSubject = "", mark = "") {
  const node = dom.subjectRowTemplate.content.cloneNode(true);
  const row = node.querySelector(".subject-row");
  const searchInput = node.querySelector(".subject-search");
  const select = node.querySelector(".subject-select");
  const input = node.querySelector(".mark-input");
  const removeBtn = node.querySelector(".remove-subject");

  searchInput.value = selectedSubject || "";
  populateSubjectSelect(select, searchInput.value, selectedSubject);
  searchInput.addEventListener("input", () => populateSubjectSelect(select, searchInput.value, select.value));
  select.addEventListener("change", () => {
    if (select.value) searchInput.value = select.value;
  });

  input.value = mark;
  removeBtn.addEventListener("click", () => row.remove());
  dom.subjects.appendChild(node);
}

function collectInput() {
  const rows = dom.subjects.querySelectorAll(".subject-row");
  const subjectMarks = [];
  const errors = [];
  const seen = new Set();

  if (!rows.length) errors.push("Add at least one subject.");

  rows.forEach((row, index) => {
    const subject = row.querySelector(".subject-select").value;
    const markValue = row.querySelector(".mark-input").value;
    const mark = Number(markValue);

    if (!subject) {
      errors.push(`Row ${index + 1}: select a subject.`);
      return;
    }
    if (seen.has(subject)) {
      errors.push(`Row ${index + 1}: duplicate subject "${subject}".`);
      return;
    }
    seen.add(subject);
    if (markValue === "" || Number.isNaN(mark) || mark < 0 || mark > 100 || !Number.isInteger(mark)) {
      errors.push(`Row ${index + 1}: mark must be an integer between 0 and 100.`);
      return;
    }
    subjectMarks.push({ subject, mark });
  });

  const nonLO = subjectMarks.filter((s) => s.subject !== "Life Orientation");
  if (nonLO.length < 6) errors.push("Enter at least 6 subjects excluding Life Orientation.");
  if (!subjectMarks.some((s) => isEnglishSubject(s.subject))) {
    errors.push("English (HL or FAL) is compulsory.");
  }
  if (!subjectMarks.some((s) => isMathChoice(s.subject))) {
    errors.push("Select Mathematics or Mathematical Literacy.");
  }

  return { gradeSource: dom.gradeSource.value, subjectMarks, errors };
}

function calculateAPS(university, subjectMarks) {
  const formula = university.aps_formula || "nsc_top6_excl_lo";

  if (formula === "uct_percentage_sum_top6_excl_lo") {
    const english = subjectMarks.find((s) => isEnglishSubject(s.subject));
    const nonLO = subjectMarks.filter((s) => s.subject !== "Life Orientation");
    if (!english) return 0;
    const others = nonLO
      .filter((s) => s.subject !== english.subject)
      .sort((a, b) => b.mark - a.mark)
      .slice(0, 5);
    return [english, ...others].reduce((sum, s) => sum + s.mark, 0);
  }

  if (formula === "uwc_weighted_points") {
    return subjectMarks.reduce((sum, s) => {
      if (s.subject === "Life Orientation") return sum + pointsUwcLO(s.mark);
      if (isEnglishSubject(s.subject) || isMathChoice(s.subject)) return sum + pointsUwcEnglishMath(s.mark);
      return sum + pointsUwcOther(s.mark);
    }, 0);
  }

  if (formula === "wits_weighted_best7_including_lo") {
    const scored = subjectMarks.map((s) => {
      if (s.subject === "Life Orientation") return { ...s, points: pointsLifeOrientationWits(s.mark) };
      if (isEnglishSubject(s.subject) || isMathChoice(s.subject)) return { ...s, points: pointsEnglishMathWits(s.mark) };
      return { ...s, points: pointsOtherFromMark(s.mark) };
    });
    return scored.sort((a, b) => b.points - a.points).slice(0, 7).reduce((sum, s) => sum + s.points, 0);
  }

  if (formula === "sun_selection_mark_average") {
    const nonLO = subjectMarks.filter((s) => s.subject !== "Life Orientation");
    const top6 = [...nonLO].sort((a, b) => b.mark - a.mark).slice(0, 6);
    if (!top6.length) return 0;
    return Math.round(top6.reduce((sum, s) => sum + s.mark, 0) / top6.length);
  }

  // Default: NSC top 6 levels excluding Life Orientation.
  const filtered = subjectMarks.filter((entry) => university.include_life_orientation || entry.subject !== "Life Orientation");
  const top6 = [...filtered].map((entry) => ({ ...entry, level: percentageToNSCLevel(entry.mark) })).sort((a, b) => b.level - a.level).slice(0, 6);
  return top6.reduce((total, entry) => total + entry.level, 0);
}

function checkSubjectMinimums(subjectMarks, requirements) {
  if (!ENFORCE_SUBJECT_MINIMUMS) return [];
  const failed = (requirements || []).filter((rule) => {
    const found = subjectMarks.find((x) => x.subject === rule.subject);
    if (!found) return true;
    return percentageToNSCLevel(found.mark) < rule.minimum_mark;
  });
  return failed;
}

function classifyProgramme({ aps, minimumAPS, failedSubjectMinimums, competitive, gradeSource }) {
  if (failedSubjectMinimums.length > 0) {
    return {
      classification: "NOT_ELIGIBLE",
      reason: `Subject minimum gap: ${failedSubjectMinimums
        .map((r) => `${r.subject} Level ${r.minimum_mark}`)
        .join(", ")}`,
    };
  }

  if (aps < minimumAPS) {
    return {
      classification: "NOT_ELIGIBLE",
      reason: `APS ${aps} is below minimum ${minimumAPS}.`,
    };
  }

  return {
    classification: "QUALIFY",
    reason: `APS ${aps} meets minimum ${minimumAPS}.`,
  };
}

function evaluateUniversity(university, gradeSource, subjectMarks) {
  if (university.status !== "active") {
    return {
      universityName: university.name,
      status: "unavailable",
      message: university.unavailable_reason || "No verified active rule set available.",
      programmes: [],
    };
  }

  if (gradeSource === "grade12_final" && !university.supports_grade12) {
    return {
      universityName: university.name,
      status: "skipped",
      message: "Final Grade 12 results are not enabled for this university.",
      programmes: [],
    };
  }

  const aps = calculateAPS(university, subjectMarks);
  const programmes = (university.courses || []).map((course) => {
    const failedSubjectMinimums = checkSubjectMinimums(subjectMarks, course.subject_minimums);
    const classificationData = classifyProgramme({
      aps,
      minimumAPS: course.minimum_aps,
      failedSubjectMinimums,
      competitive: Boolean(course.competitive_flag),
      gradeSource,
    });

    return {
      name: course.name,
      minimumAPS: course.minimum_aps,
      classification: classificationData.classification,
      reason: classificationData.reason,
      subjectMinimums: course.subject_minimums || [],
      competitive: Boolean(course.competitive_flag),
      stream: course.mainstream_or_extended || "mainstream",
    };
  });

  const eligibleProgrammes = programmes.filter((p) =>
    p.classification === "QUALIFY"
  );

  return {
    universityName: university.name,
    status: eligibleProgrammes.length ? "visible" : "hidden",
    aps,
    apsFormula: university.aps_formula || "nsc_top6_excl_lo",
    applicationFee: university.application_fee || "Not provided",
    ruleVersion: university.rule_version || "unknown",
    confidence: university.extraction_confidence,
    programmes: eligibleProgrammes,
    eligibleProgrammes,
  };
}

function evaluateForInput(input) {
  const evaluated = universityRules.map((uni) => evaluateUniversity(uni, input.gradeSource, input.subjectMarks));
  const visible = evaluated.filter((u) => u.status === "visible");
  const totalEligible = visible.reduce((sum, u) => sum + u.eligibleProgrammes.length, 0);
  return { evaluated, visible, totalEligible };
}

function renderImprovementModel(input, baselineTotal) {
  const improvements = [];
  input.subjectMarks.forEach((entry, index) => {
    if (entry.mark >= 100) return;
    const nextMark = Math.min(100, entry.mark + 10);
    const cloned = input.subjectMarks.map((s, i) =>
      i === index ? { ...s, mark: nextMark } : { ...s }
    );
    const scenario = evaluateForInput({
      gradeSource: input.gradeSource,
      subjectMarks: cloned,
    });
    const unlocked = scenario.totalEligible - baselineTotal;
    if (unlocked > 0) {
      improvements.push(
        `${entry.subject}: ${entry.mark}% -> ${nextMark}% unlocks ${unlocked} programme(s)`
      );
    }
  });

  if (!improvements.length) {
    dom.improvementModel.innerHTML = "";
    return;
  }

  dom.improvementModel.innerHTML = `
    <p><strong>Improvement Modelling</strong></p>
    <ul>${improvements.map((i) => `<li>${i}</li>`).join("")}</ul>
  `;
}

function renderResults(visibleUniversities) {
  dom.results.innerHTML = "";
  if (!visibleUniversities.length) {
    dom.results.innerHTML = "<p class='small'>No eligible universities/programmes for this profile yet.</p>";
    return;
  }

  visibleUniversities.forEach((result) => {
    const card = document.createElement("article");
    card.className = "university-card";
    const displayProgrammes = (result.programmes || result.eligibleProgrammes || []).filter((p) =>
      p.classification === "QUALIFY"
    );
    const qualifyingList = `
      <p><strong>Qualifying Programmes</strong></p>
      <ul>${displayProgrammes
        .map(
          (p) => {
            const subjectLine = p.subjectMinimums.length
              ? `Subject minimums met: ${p.subjectMinimums
                  .map((rule) => `${rule.subject} Level ${rule.minimum_mark}`)
                  .join(", ")}.`
              : "No additional subject minimums required.";
            return `<li><strong>${p.name}</strong> (${p.stream})<br /><span class="small">${p.reason} ${subjectLine}</span></li>`;
          }
        )
        .join("")}</ul>
    `;

    card.innerHTML = `
      <div class="university-header">
        <strong>${result.universityName}</strong>
        <span class="badge">APS: ${result.aps}</span>
      </div>
      <p class="small">Application fee: ${result.applicationFee}</p>
      <p class="small">APS formula: ${result.apsFormula}</p>
      <p class="small">Rule version: ${result.ruleVersion}</p>
      ${qualifyingList}
    `;
    dom.results.appendChild(card);
  });
}

function saveLastResult(payload) {
  localStorage.setItem(STORAGE_KEYS.lastResult, JSON.stringify(payload));
}

function clearLegacyStorage() {
  [
    "unipath_last_result",
    "unipath_last_result_v2",
    "unipath_rules_cache",
  ].forEach((key) => localStorage.removeItem(key));
}

function loadLastResult() {
  const raw = localStorage.getItem(STORAGE_KEYS.lastResult);
  if (!raw) return;
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed.subjectMarks)) {
      dom.subjects.innerHTML = "";
      parsed.subjectMarks.forEach((s) => addSubjectRow(s.subject, s.mark));
    }
    if (parsed.gradeSource) dom.gradeSource.value = parsed.gradeSource;
    updateGradeSourceNotice();
    if (Array.isArray(parsed.visibleResults)) renderResults(parsed.visibleResults);
    if (parsed.confidenceMessage) dom.confidenceNotice.textContent = parsed.confidenceMessage;
    if (parsed.improvementHtml) dom.improvementModel.innerHTML = parsed.improvementHtml;
  } catch {
    localStorage.removeItem(STORAGE_KEYS.lastResult);
  }
}

function saveRulesCache(payload) {
  localStorage.setItem(STORAGE_KEYS.rulesCache, JSON.stringify(payload));
}

function loadRulesCache() {
  const raw = localStorage.getItem(STORAGE_KEYS.rulesCache);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    localStorage.removeItem(STORAGE_KEYS.rulesCache);
    return null;
  }
}

async function loadRules() {
  try {
    const response = await fetch("./data/approved_rules.json", { cache: "no-store" });
    if (!response.ok) throw new Error("Could not load rules file");
    const payload = await response.json();
    if (!Array.isArray(payload.universities)) throw new Error("Invalid rules schema");
    universityRules = payload.universities;
    saveRulesCache(payload);
  } catch (error) {
    const fallback = loadRulesCache();
    if (fallback && Array.isArray(fallback.universities)) {
      universityRules = fallback.universities;
      dom.errors.textContent = "Using cached rules. Connect to refresh latest university data.";
      return;
    }
    dom.errors.textContent = `Rules unavailable: ${error.message}`;
  }
}

function onSubmit(event) {
  event.preventDefault();
  dom.errors.textContent = "";
  dom.confidenceNotice.textContent = "";
  dom.improvementModel.innerHTML = "";

  if (!Array.isArray(universityRules) || universityRules.length === 0) {
    dom.errors.textContent = "No university rules loaded yet. Try again in a few seconds.";
    return;
  }

  const input = collectInput();
  if (input.errors.length) {
    dom.errors.textContent = input.errors.join(" ");
    return;
  }

  const evaluation = evaluateForInput(input);
  renderResults(evaluation.visible);

  const confidence = getConfidenceLabel(input.gradeSource);
  dom.confidenceNotice.textContent = `Confidence: ${confidence}. Results are predictive and may change based on final performance.`;
  renderImprovementModel(input, evaluation.totalEligible);

  saveLastResult({
    gradeSource: input.gradeSource,
    subjectMarks: input.subjectMarks,
    visibleResults: evaluation.visible,
    confidenceMessage: dom.confidenceNotice.textContent,
    improvementHtml: dom.improvementModel.innerHTML,
  });
}

function resetAll() {
  localStorage.removeItem(STORAGE_KEYS.lastResult);
  dom.errors.textContent = "";
  dom.confidenceNotice.textContent = "";
  dom.improvementModel.innerHTML = "";
  dom.results.innerHTML = "<p class='small'>No results yet.</p>";
  dom.gradeSource.value = "grade11_final";
  dom.subjects.innerHTML = "";
  addSubjectRow();
  addSubjectRow();
  updateGradeSourceNotice();
}

async function init() {
  dom.addSubjectBtn.addEventListener("click", () => addSubjectRow());
  dom.form.addEventListener("submit", onSubmit);
  dom.resetAllBtn.addEventListener("click", resetAll);
  dom.gradeSource.addEventListener("change", updateGradeSourceNotice);

  clearLegacyStorage();
  addSubjectRow();
  addSubjectRow();
  updateGradeSourceNotice();
  loadLastResult();
  await loadRules();
}

init();
